#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Please don't remove this disclaimer

#############################################
#                                           #
#    Sherlock mod (py3) from Evg77734       #
#                                           #
#############################################

from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Sensors import sensors
from GlobalActions import globalActionMap
from enigma import eConsoleAppContainer, iServiceInformation, getDesktop, eTimer, iPlayableService
from os import listdir, popen
from Components.Sources.StaticText import StaticText
from enigma import ePoint, iPlayableService
from Components.ServiceEventTracker import ServiceEventTracker
from Tools.Directories import pathExists, fileExists
from .bitrate import Bitrate
from Components.Pixmap import Pixmap
import os
from .screens.skin import *
from Plugins.Extensions.Sherlockmod.Console2 import Console2
from .compat import compat_urlopen, compat_Request, compat_URLError, PY3

global n
n = 1

def getversioninfo():
    import os
    currversion = '1.4'
    version_file = '/usr/lib/enigma2/python/Plugins/Extensions/Sherlockmod/version'
    if os.path.exists(version_file):
        try:
            fp = open(version_file, 'r').readlines()
            for line in fp:
                if 'version' in line:
                    currversion = line.split('=')[1].strip()
        except:
            pass
    return (currversion)

Ver = getversioninfo()


systemTxtCaids = {'26': 'BiSS',
         '01': 'Seca Mediaguard',
         '06': 'Irdeto',
         '17': 'BetaCrypt',
         '05': 'Viacces',
         '18': 'Nagravision',
         '09': 'NDS-Videoguard',
         '0B': 'Conax',
         '0D': 'Cryptoworks',
         '4A': 'DRE-Crypt',
         '27': 'ExSet',
         '0E': 'PowerVu',
         '22': 'Codicrypt',
         '07': 'DigiCipher',
         '56': 'Verimatrix',
         '7B': 'DRE-Crypt',
         'A1': 'Rosscrypt'}

class Sherlock(Screen):
	sz_w = getDesktop(0).size().width()
	if sz_w == 1920:
		skin = SHERLOCK_HD
	else:
		skin = SHERLOCK_SD
		
	def __init__(self, session, args = 0):
		self.session = session
		Screen.__init__(self, session)
		self.InfoFiles = []
		self.IFindex = 0
		self.InfoActive = False
		self["daten"] = Label(_(" "))
		self["system_info"] = Label(_(" "))
		self["signal_info"] = Label(_(" "))
		self["dccamdName"] = Label(_(" "))
		self["dataFileName"] = Label(_(" "))
		self["OrbitalPosition"] = Label(_(" "))
		self["pic1"] = Pixmap()
		self["pic2"] = Pixmap()
		self.onShow.append(self.loadpic)
		self["actions"] = ActionMap(["OkCancelActions", "DirectionActions", "HelpActions", "EPGSelectActions", "ColorActions"],
		{
			"ok": self.ExitSherlock,
			"cancel": self.ExitSherlock,
			"left": self.left,
			"right": self.right,
			"info": self.about,
			"blue": self.bluebutton,
		}, -1)
		self.SysUpdateTimer = eTimer()
		self.SysUpdateTimer.callback.append(self.updateSysInfo)
		self.onLayoutFinish.append(self.DataReader)
		
		self.startDelayTimer = eTimer()
		self.startDelayTimer.callback.append(self.bitrateAfrterDelayStart)
		self["video"] = StaticText()
		self["audio"] = StaticText()
		self.bitrate = Bitrate(session, self.refreshEvent, self.bitrateStopped)
		self.onLayoutFinish.append(self.__layoutFinished)
		self.checkupdates()
	
	def checkupdates(self):
		url = 'https://raw.githubusercontent.com/kaleem87/Sherlockmod/main/installer.sh'
		self.callUrl(url, self.checkVer)

	def checkVer(self, data):
		if PY3:
			data = data.decode("utf-8")
		else:
			data = data.encode("utf-8")
		if data:
			lines = data.split("\n")
			for line in lines:
				if line.startswith("version"):
					self.new_version = line.split("=")[1]
				if line.startswith("description"):
					self.new_description = line.split("=")[1]
					break
		if float(Ver) == float(self.new_version) or float(Ver) > float(self.new_version):
			pass
		else:
			new_version = self.new_version
			new_description = self.new_description
			self.session.openWithCallback(self.installupdate, MessageBox, _('New version of Sherlockmod is available.\n\n%s.\n\nDo you want to install it now.' % (self.new_version, self.new_description)), MessageBox.TYPE_YESNO)

	def installupdate(self, answer=False):
		if answer:
			cmdlist = []
			cmdlist.append('wget -q "--no-check-certificate" https://raw.githubusercontent.com/kaleem87/Sherlockmod/main/installer.sh -O - | /bin/sh')
			self.session.open(Console2, title='Update Sherlockmod by Biko', cmdlist=cmdlist, finishedCallback=self.myCallback, closeOnSuccess=False)
















	def bluebutton(self):
		self.session.open(Emulator)
	
	def about(self):
		self.session.open(MessageBox, _("Sherlock mod ver. ") + version + _("\n\nDeveloper: Evg77734\n\nHomepage: gisclub.tv, tvfaq.net, giclub.tv"), MessageBox.TYPE_INFO)
		
	def ExitSherlock(self):
		try:
			global n
			s = open("/usr/lib/enigma2/python/Plugins/Extensions/Sherlockmod/sherlock.conf", "w")
			s.write(str(n))
			s.close()
		except:
			pass
		self.bitrate.stop()
		self.close()

	def DataReader(self):
		srv_Text = "N/A"
		ca_Text = " "
		ar_fec = ["Auto", "1/2", "2/3", "3/4", "5/6", "7/8", "3/5", "4/5", "8/9", "9/10", "n/a", "n/a", "n/a", "n/a", "n/a", "n/a"]
		ar_pol = ["H", "V", "CL", "CR", "n/a", "n/a", "n/a", "n/a", "n/a", "n/a", "n/a", "n/a"]
		service = self.session.nav.getCurrentService()
		info = service and service.info()
		orbital_pos = 0
		if info is not None:
			xresol = info.getInfo(iServiceInformation.sVideoWidth)
			yresol = info.getInfo(iServiceInformation.sVideoHeight)
			feinfo = (service and service.frontendInfo())
			if (feinfo is not None) and (xresol>0):
				srv_Text = "Size: " + str(xresol) + "x" + str(yresol) + "\n"
				frontendData = (feinfo and feinfo.getAll(True))
				if (frontendData is not None):
					if (frontendData.get("tuner_type") == "DVB-S"):
						orbital_pos = int(frontendData["orbital_position"])
						if orbital_pos > 1800:
							self["OrbitalPosition"].setText(str((float(3600 - orbital_pos))/10.0) + "W")
						elif orbital_pos > 0:
							self["OrbitalPosition"].setText(str((float(orbital_pos))/10.0) + "E")
					if ((frontendData.get("tuner_type") == "DVB-S") or (frontendData.get("tuner_type") == "DVB-C")):
						frequency = "FQ:" + str(frontendData.get("frequency") / 1000)
						symbolrate = "SR:" + str(frontendData.get("symbol_rate") / 1000)
						if (frontendData.get("tuner_type") == "DVB-S"):
							polarisation_i = frontendData.get("polarization")
						else:
							polarisation = 0
						fec_i = frontendData.get("fec_inner")
						try:
							srv_Text = srv_Text + frequency + "  " + ar_pol[polarisation_i] + "  " + ar_fec[fec_i] + "  " + symbolrate
						except:
							srv_Text = srv_Text + frequency + "    " + symbolrate
					elif (frontendData.get("tuner_type") == "DVB-T"):
						frequency = str(frontendData.get("frequency") / 1000) + " MHz"
						srv_Text = srv_Text + frequency
		self["signal_info"].setText(_(srv_Text))
		self["dccamdName"].setText(self.is_dccamd_running())
		self.searchInfoFiles()
		self.updateSysInfo()
		self.SysUpdateTimer.start(5000)
#		bit_srv = self.session.nav.getCurrentService()
		###############################################################

	def is_dccamd_running(self):
		control = 0
		cfgfile = '/tmp/ecm.info'
		emu = 'Channel Free-To-Air'
		
		if cfgfile:
			try:
				f = open(cfgfile, 'r')
				content = f.read()
				f.close()
			except:
				content = ''
			contentInfo = content.split('\n')
			for line in contentInfo:
				if '=====' in line:
					control = 1
				if 'using' in line:
					emu = 'Emulator is used:  ' + 'CCCAM'
				elif 'source' in line and 'system:' not in line:
					emu = 'Emulator is used:  ' + 'MGCAMD'
				elif 'reader' in line or 'system:' in line:
					if fileExists('/tmp/.ncam/ncam.version'):
						emu = 'Emulator is used:  ' + 'NCAM'
					else:
						emu = 'Emulator is used:  ' + 'OSCAM'
				if 'reader' in line or 'system:' in line:
					if fileExists('/tmp/.gcam/gcam.version'):
						emu = 'Emulator is used:  ' + 'GCAM'
				elif 'using' in line and control == 1 and 'system:' not in line or 'response time' in line:
					emu = 'Emulator is used:  ' + 'WICARDD'
				elif 'CAID' in line:
					emu = 'Emulator is used:  ' + 'CAMD3'
		return emu
		
	def updateSysInfo(self):
		try:
			ret = ""
			out_line = popen("cat /proc/loadavg").readline()
			ret = "load average   " + out_line[:15] + "\n" + "\n"
			out_lines = []
			out_lines = popen("cat /proc/meminfo").readlines()
			for lidx in range(len(out_lines)-1):
				tstLine = out_lines[lidx].split()
				if "MemFree:" in tstLine:
					ret = ret + out_lines[lidx]
			res = ""
			service = self.session.nav.getCurrentService()
			info = service and service.info()
			if info is not None:
				if info.getInfo(iServiceInformation.sIsCrypted):
					searchIDs =(info.getInfoObject(iServiceInformation.sCAIDs))
					for oneID in searchIDs:
						if res:
							res = res + ", "
						temp_str = hex(oneID).lstrip("0x")
						if (len(temp_str)==4):
							res = res + temp_str.upper()
						else:
							res = res + "0" + temp_str.upper()
					res = "HDD in C:          " + self.TempMessung() + "\ncaid " + res
					
				else:
					res = res + "\nHDD in C:          " + self.TempMessung()
			
			 
			ret = ret + res
		except:
			ret = "N/A"
		self["system_info"].setText(_(ret))
		if len(self.InfoFiles) > 0:
			try:
				f = open(self.InfoFiles[self.IFindex], "r")
				data_lines=f.readlines()
				f.close()
				Data_Text=""
				for i in range(0, len(data_lines)):
					Data_Text = Data_Text + data_lines[i]
				
			except:
				Data_Text="No data-file found."
			self["daten"].setText(_(Data_Text))
			self["dataFileName"].setText(self.InfoFiles[self.IFindex])
			
	def searchInfoFiles(self):
		files = listdir('/tmp/')
		files.sort()
		for name in files:
			testname = name.lower()
			if testname.endswith("m.info"):
				self.InfoFiles.append('/tmp/'+name)

	def TempMessung(self):
		maxtemp = 0
		sensotN = "?"
		try:
			maxtemp = popen("hddtemp -n -q /dev/sda").readline()
			maxtemp.close()
		except:
			pass
		return str(maxtemp)

	def __layoutFinished(self):
		self.bitrateUpdateStart()

	def bitrateUpdateStart(self, delay=0):
		self.startDelayTimer.stop()
		self.startDelayTimer.start(delay, True)

	def bitrateAfrterDelayStart(self):
		if not self.bitrateUpdateStatus():
			self.bitrate.start()

	def bitrateUpdateStatus(self):
		return self.bitrate.running

	def bitrateUpdateStop(self):
		self.startDelayTimer.stop()
		if self.bitrateUpdateStatus():
			self.bitrate.stop()

	def refreshEvent(self):
		self["video"].setText(str(self.bitrate.vcur) + _(" kbit/s"))
		self["audio"].setText(str(self.bitrate.acur) + _(" kbit/s"))
		
	def bitrateStopped(self, retval):
		self.close()

	def left(self):
		sz_w = getDesktop(0).size().width()
		if sz_w == 1920:
			global n
			n = n - 1
			if n < 1:
				n = 9
			self["pic1"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Sherlockmod/images/fon1" + str(n) + ".png")
			self["pic1"].instance.show()
			self["pic2"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Sherlockmod/images/fon2" + str(n) + ".png")
			self["pic2"].instance.show()
		else:
			n = 1
			self["pic1"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Sherlockmod/images/fon3" + str(n) + ".png")
			self["pic1"].instance.show()
			self["pic2"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Sherlockmod/images/fon4" + str(n) + ".png")
			self["pic2"].instance.show()
	
	def right(self):
		sz_w = getDesktop(0).size().width()
		if sz_w == 1920:
			global n
			n = n + 1
			if n > 9:
				n = 1
			self["pic1"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Sherlockmod/images/fon1" + str(n) + ".png")
			self["pic1"].instance.show()
			self["pic2"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Sherlockmod/images/fon2" + str(n) + ".png")
			self["pic2"].instance.show()
		else:
			n = 1
			self["pic1"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Sherlockmod/images/fon3" + str(n) + ".png")
			self["pic1"].instance.show()
			self["pic2"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Sherlockmod/images/fon4" + str(n) + ".png")
			self["pic2"].instance.show()
	
	def loadpic(self):
		if os.path.exists("/usr/lib/enigma2/python/Plugins/Extensions/Sherlockmod/sherlock.conf") == True:
			global n
			with open("/usr/lib/enigma2/python/Plugins/Extensions/Sherlockmod/sherlock.conf", "r") as file:
				contents = file.readlines()
			s = int(contents[0])
			n = s
			file.close()
		else:
			n = 1
		sz_w = getDesktop(0).size().width()
		if sz_w == 1920:
			self["pic1"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Sherlockmod/images/fon1" + str(n) + ".png")
			self["pic1"].instance.show()
			self["pic2"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Sherlockmod/images/fon2" + str(n) + ".png")
			self["pic2"].instance.show()
		else:
			n = 1
			self["pic1"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Sherlockmod/images/fon3" + str(n) + ".png")
			self["pic1"].instance.show()
			self["pic2"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Sherlockmod/images/fon4" + str(n) + ".png")
			self["pic2"].instance.show()
			
class Emulator(Screen):
	sz_w = getDesktop(0).size().width()
	if sz_w == 1920:
		skin = Emulator_HD
	else:
		skin = Emulator_SD
		
	def __init__(self, session, args = 0):
		self.session = session
		Screen.__init__(self, session)
		self.InfoFiles = []
		self.IFindex = 0
		self["tit"] = StaticText(_("EMU Info"))
		self["str"] = StaticText(" ")	
		self["daten"] = StaticText(_(" "))
		self["system_info"] = StaticText(_(" "))
		self["emucam"] = Pixmap()
		self["caid"] = StaticText(" ")		
		self["actions"] = ActionMap(["OkCancelActions", "DirectionActions", "HelpActions", "EPGSelectActions", "ColorActions"],
		{
			"cancel": self.ExitEmulator,
		}, -1)
		self.SysUpdateTimer = eTimer()
		self.SysUpdateTimer.callback.append(self.updateSysInfo)
		self.onLayoutFinish.append(self.DataReader)

	def ExitEmulator(self):
		self.close()

	def DataReader(self):
		self.searchInfoFiles()
		self.updateSysInfo()
		self.SysUpdateTimer.start(5000)

	def updateSysInfo(self):
		sz_w = getDesktop(0).size().width()
		if sz_w == 1920:
			campic = ['oscam.png', 'wicardd.png', 'ncam.png', 'oscamymod.png', 'mgcamd.png', 'nocam.png', 'cccam.png']
		else:
			campic = ['oscam1.png', 'wicardd1.png', 'ncam1.png', 'oscamymod1.png', 'mgcamd1.png', 'nocam1.png', 'cccam1.png']
		
		pathcampic = '/usr/lib/enigma2/python/Plugins/Extensions/Sherlockmod/images/'
			
		lfile = '/tmp/zero.log'
		nfile = self.EmuInfo()
		self["tit"].setText("EMU Info  " + 'Emulator is used:  ' + nfile.upper())
		if nfile == 'oscam':
			lfile = '/tmp/oscam.log'
			self["emucam"].instance.setPixmapFromFile(pathcampic + campic[0])
			self["emucam"].instance.show()
			self["caid"].setText(str(self.CaidInfo1()))
		if nfile == 'wicardd':
			lfile = '/tmp/wicardd.log'
			self["emucam"].instance.setPixmapFromFile(pathcampic + campic[1])
			self["emucam"].instance.show()
			self["caid"].setText(str(self.CaidInfo1()))
		if nfile == 'ncam':
			lfile = '/tmp/ncam.log'
			self["emucam"].instance.setPixmapFromFile(pathcampic + campic[2])
			self["emucam"].instance.show()
			self["caid"].setText(str(self.CaidInfo1()))
		if nfile == 'oscam-ymod':
			lfile = '/tmp/ymod.log'
			self["emucam"].instance.setPixmapFromFile(pathcampic + campic[3])
			self["emucam"].instance.show()
			self["caid"].setText(str(self.CaidInfo1()))
		if nfile == 'mgcamd':
			lfile = '/tmp/mgcamd.log'
			self["emucam"].instance.setPixmapFromFile(pathcampic + campic[4])
			self["emucam"].instance.show()
			self["caid"].setText(str(self.CaidInfo3()))
		if nfile == 'No EMU':
			self["emucam"].instance.setPixmapFromFile(pathcampic + campic[5])
			self["emucam"].instance.show()
			self["caid"].setText('nodecode')
		if nfile == 'cccam':
			self["emucam"].instance.setPixmapFromFile(pathcampic + campic[6])
			self["emucam"].instance.show()
			self["caid"].setText(str(self.CaidInfo2()))
		
		if os.path.exists(lfile) == True:
			try:
				
				with open(lfile) as f:
					count = sum(1 for _ in f)
				
				f = open(lfile, "r")
				data_lines = f.readlines()
				f.close()
				try:
					Data_Text = ""
					for i in range(count-18, count):
						Data_Text = Data_Text + data_lines[i]
				except:
					Data_Text = ""
					for i in range(count-1, count):
						Data_Text = Data_Text + data_lines[i]
				
				self["str"].setText(str(Data_Text))
				
			except UnicodeDecodeError:
				self["str"].setText("UnicodeDecodeError: utf-8 codec cannot decode some byte: Invalid continuation byte in log file")
		else:
			self["str"].setText("No live log")
#######################################################################
		if len(self.InfoFiles) > 0:
			try:
				f = open(self.InfoFiles[self.IFindex], "r")
				data_lines = f.readlines()
				f.close()
				Data_Text = ""
				for i in range(0, len(data_lines)):
					Data_Text = Data_Text + data_lines[i]
				
			except:
				Data_Text="No data-file found."
			self["daten"].setText(_(Data_Text))
#######################################################################
		try:
			res = " "
			service = self.session.nav.getCurrentService()
			info = service and service.info()
			if info is not None:
				if info.getInfo(iServiceInformation.sIsCrypted):
					searchIDs =(info.getInfoObject(iServiceInformation.sCAIDs))
					for oneID in searchIDs:
						if res:
							res = res + "  "
						temp_str = hex(oneID).lstrip("0x")
						if (len(temp_str)==4):
							res = res + temp_str.upper()
						else:
							res = res + "0" + temp_str.upper()
					res = res
					
				else:
					res = " "
			
			else:
				res = " "
			res = res
		except:
			res = "N/A"
		self["system_info"].setText(_(res))

	def searchInfoFiles(self):
		files = listdir('/tmp/')
		files.sort()
		for name in files:
			testname = name.lower()
			if testname.endswith("m.info"):
				self.InfoFiles.append('/tmp/'+name)

	def EmuInfo(self):
		folder_paths = []
		MYDIR = '/proc/'
		for entry_name in os.listdir(MYDIR):
			entry_path = os.path.join(MYDIR, entry_name)
			if os.path.isdir(entry_path):
				folder_paths.append(entry_path)

		emu = "No EMU"
		m = 0
		while m < len(folder_paths):
			if os.path.exists(folder_paths[m] + "/comm") == True:
				with open(folder_paths[m] + "/comm", "r") as file:
					contents = file.readlines()
					a = str(contents[0])
				procemu = a.rstrip()
				file.close()
				femu = "ymod"
				if femu.lower() in procemu.lower():
					emu = "oscam-ymod"
					break
				femu = "Oscam"
				if femu.lower() in procemu.lower():
					emu = "oscam"
					break
				femu = "wicardd"
				if femu.lower() in procemu.lower():
					emu = "wicardd"
					break
				femu = "ncam"
				if femu.lower() in procemu.lower():
					emu = "ncam"
					break
				femu = "cccam"
				if femu.lower() in procemu.lower():
					emu = "cccam"
					break
				femu = "mgcamd"
				if femu.lower() in procemu.lower():
					emu = "mgcamd"
					break
		
			m = m + 1

		return emu

	def CaidInfo1(self):
		if os.path.exists('/tmp/ecm.info') == True:
			ecmf = open('/tmp/ecm.info', 'r')
			ecm = ecmf.readlines()
			for line in ecm:
				if 'caid: 0x' in line or 'CAID: 0x' in line:
					x = line
					l = len(x)
					x1 = x[8:l]
					d = '%s' % systemTxtCaids.get(x1[:2])
			return d
		else:
			d = 'nodecode'
			return d
	
	def CaidInfo2(self):
		if os.path.exists('/tmp/ecm.info') == True:
			ecmf = open('/tmp/ecm.info', 'r')
			ecm = ecmf.readlines()
			for line in ecm:
				if 'system:     ' in line:
					x = line
					l = len(x)
					x1 = x[12:l]
					d = x1
			return d
		else:
			d = 'nodecode'
			return d

	def CaidInfo3(self):
		if os.path.exists('/tmp/ecm.info') == True:
			ecmf = open('/tmp/ecm.info', 'r')
			ecm = ecmf.readlines()
			for line in ecm:
				if 'CaID 0x' in line:
					x = line
					l = len(x)
					y = x.find('CaID 0x')
					
					x1 = x[(y+7):l]
					d = '%s' % systemTxtCaids.get(x1[:2])
			return d
		else:
			d = 'nodecode'
			return d
	
def main(session, **kwargs):
	session.open(Sherlock)

def Plugins(path, **kwargs):
	return PluginDescriptor(name = _("Sherlock mod"), where = [PluginDescriptor.WHERE_PLUGINMENU], description = _("Sherlock mod by Evg77734 - mod2_skin by Biko ver. " + version), icon = 'sherlock.png', fnc = main)
    